package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import com.entity.TodoDetails;

public class TodoDAO {
    private Connection conn;

    public TodoDAO(Connection conn) {
        this.conn = conn;
    }

    public boolean addTodo(int id, String todo, Date targetdate, String status) {  
        boolean f = false;
        try {
            String sql = "INSERT INTO add_todo(id, todo, targetdate, status) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            ps.setString(2, todo);
            ps.setDate(3, targetdate);
            ps.setString(4, status);

            int i = ps.executeUpdate();
            if (i == 1) {
                f = true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return f;
    }

    public List<TodoDetails> getTodo() {
        List<TodoDetails> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM add_todo";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                TodoDetails t = new TodoDetails();
                t.setId(rs.getInt(1));
                t.setTodo(rs.getString(2));
                t.setDate(rs.getDate(3)); // ✅ No need to convert Date to String
                t.setStatus(rs.getString(4));
                list.add(t);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    
    
    public TodoDetails getTodoById(int id) {
        TodoDetails t = null;
        try {
            String sql = "SELECT * FROM add_todo WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {  
                t = new TodoDetails();
                t.setId(rs.getInt(1));
                t.setTodo(rs.getString(2));
                t.setDate(rs.getDate(3)); // ✅ Corrected
                t.setStatus(rs.getString(4));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return t;
    }
    
    
    public boolean updateTodo(TodoDetails t) {
        boolean f = false;
        try {
            String sql = "UPDATE add_todo SET todo=?, targetdate=?, status=? WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, t.getTodo());
            ps.setDate(2, t.getDate()); 
            ps.setString(3, t.getStatus());
            ps.setInt(4, t.getId());

            int i = ps.executeUpdate();
            if (i == 1) {
                f = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return f;
    }

    public boolean deleteTodo(int id) {
        boolean f = false;
        try {
            String sql = "DELETE FROM add_todo WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            
            int i = ps.executeUpdate();
            if (i == 1) {
                f = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return f;
    }
}

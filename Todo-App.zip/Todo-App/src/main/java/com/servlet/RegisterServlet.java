package com.servlet;

import java.io.IOException;
import com.DAO.UserDAO;
import com.DB.DBConnect;
import com.entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.RequestDispatcher;  

@WebServlet("/Register")
public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String usn = req.getParameter("usn");
        String name = req.getParameter("name");
        String email = req.getParameter("email");
        String password = req.getParameter("password"); 

        User user = new User(usn, name, email, password);
        UserDAO dao = new UserDAO(DBConnect.getConnection());
        boolean success = dao.registerUser(user);

        if (success) {
            req.setAttribute("sucMsg", "Registration Successful! Please login.");
        } else {
            req.setAttribute("failMsg", "Email is already registered! Try another.");
        }

        RequestDispatcher dispatcher = req.getRequestDispatcher("register.jsp");
        dispatcher.forward(req, resp);
    }
}

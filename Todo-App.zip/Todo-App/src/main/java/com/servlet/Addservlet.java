package com.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;  
import com.DAO.TodoDAO;
import com.DB.DBConnect;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/add_todo")
public class Addservlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String idStr = req.getParameter("id");  
        String todo = req.getParameter("todo");
        String eDateStr = req.getParameter("edate");
        String status = req.getParameter("status");

        try {
            int id = Integer.parseInt(idStr);  
            Date eDate = Date.valueOf(eDateStr);  

            Connection conn = DBConnect.getConnection(); 
            TodoDAO dao = new TodoDAO(conn);

            boolean f = dao.addTodo(id, todo, eDate, status);  
            HttpSession session = req.getSession();
            if (f) {
               session.setAttribute("sucMsg", "Todo Added Successfully");
               resp.sendRedirect("home.jsp");
            } else {
               session.setAttribute("failMsg", "Error");
               resp.sendRedirect("index.jsp");
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
            req.getSession().setAttribute("failMsg", "Invalid ID format");
            resp.sendRedirect("index.jsp");
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
            req.getSession().setAttribute("failMsg", "Invalid Date format");
            resp.sendRedirect("index.jsp");
        }
    }
}

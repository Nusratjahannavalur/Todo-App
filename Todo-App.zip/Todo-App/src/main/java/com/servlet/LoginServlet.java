package com.servlet;

import java.io.IOException;
import com.DAO.UserDAO;
import com.DB.DBConnect;
import com.entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String email = req.getParameter("email");
        String password = req.getParameter("password");

        UserDAO dao = new UserDAO(DBConnect.getConnection());
        User user = dao.validateUser(email, password); // Check credentials

        HttpSession session = req.getSession();
        
        if (user != null) {
            session.setAttribute("userObj", user); // Store user data in session
            resp.sendRedirect("home.jsp"); // Redirect to home page
        } else {
            session.setAttribute("errorMsg", "Invalid Email or Password!");
            resp.sendRedirect("login.jsp"); // Redirect back to login
        }
    }
}

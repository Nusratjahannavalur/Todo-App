package com.servlet;

import java.io.IOException;
import java.sql.Date;

import com.DAO.TodoDAO;
import com.DB.DBConnect;
import com.entity.TodoDetails;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/Update")
public class UpdateServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            int id = Integer.parseInt(req.getParameter("id"));
            String todo = req.getParameter("todo");
            String eDateStr = req.getParameter("edate");
            String status = req.getParameter("status");

            // ✅ Convert String to java.sql.Date
            Date eDate = Date.valueOf(eDateStr);

            TodoDAO dao = new TodoDAO(DBConnect.getConnection());
            TodoDetails t = new TodoDetails();
            t.setId(id);
            t.setTodo(todo);
            t.setDate(eDate);  // ✅ Pass Date object instead of String
            t.setStatus(status);

            boolean f = dao.updateTodo(t);
            HttpSession session = req.getSession();

            if (f) {
                session.setAttribute("sucMsg", "Todo Updated Successfully");
            } else {
                session.setAttribute("failMsg", "Error in updating Todo");
            }
            resp.sendRedirect("home.jsp");
        } catch (IllegalArgumentException e) {  // ✅ Catch only IllegalArgumentException
            e.printStackTrace();
        }
    }
}

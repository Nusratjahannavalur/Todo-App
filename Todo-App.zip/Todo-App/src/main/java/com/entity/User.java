package com.entity;

public class User {
    private String usn;
    private String name;
    private String email;
    private String password;

    // ✅ Default constructor (fixes the issue)
    public User() {
    }

    // ✅ Parameterized constructor
    public User(String usn, String name, String email, String password) {
        this.usn = usn;
        this.name = name;
        this.email = email;
        this.password = password;
    }

    // Getters and Setters
    public String getUsn() {
        return usn;
    }

    public void setUsn(String usn) {
        this.usn = usn;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}

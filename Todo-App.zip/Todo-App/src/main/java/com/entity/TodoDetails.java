package com.entity;

import java.sql.Date;

public class TodoDetails {
    private int id;
    private String todo;
    private Date date;  // ✅ Changed to Date for better database compatibility
    private String status;

    // Default Constructor
    public TodoDetails() {}

    // Parameterized Constructor
    public TodoDetails(int id, String todo, Date date, String status) {
        this.id = id;
        this.todo = todo;
        this.date = date;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTodo() {
        return todo;
    }

    public void setTodo(String todo) {
        this.todo = todo;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "TodoDetails { id=" + id + ", todo='" + todo + "', date=" + date + ", status='" + status + "' }";
    }
}

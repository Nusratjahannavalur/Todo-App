<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Register</title>
<%@include file="components/all_css.jsp"%>

<style>
    body {
        background: linear-gradient(to right, #81c784, #66bb6a); /* Light Green Background */
        font-family: 'Poppins', sans-serif;
    }

    .card {
        background-color: white;
        border-radius: 10px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }

    .card-body {
        padding: 30px;
    }

    h3 {
        color: #388e3c; /* Darker Green for Heading */
        margin-bottom: 20px;
    }

    .form-group label {
        font-weight: bold;
        color: #388e3c; /* Dark Green Label */
    }

    .form-control {
        border-radius: 5px;
        padding: 10px;
        font-size: 16px;
        border: 1px solid #81c784; /* Light Green Border */
    }

    .form-control:focus {
        border-color: #66bb6a; /* Darker Green Focus */
        box-shadow: 0 0 5px #66bb6a;
    }

    .btn-primary {
        background-color: #81c784; /* Light Green */
        color: white;
        font-weight: bold;
        border-radius: 50px;
        padding: 12px 20px;
        transition: all 0.3s ease-in-out;
    }

    .btn-primary:hover {
        background-color: #66bb6a; /* Darker Green on hover */
        transform: scale(1.05);
    }

    .alert {
        font-weight: bold;
    }

    .text-center {
        text-align: center;
    }

    .mt-3 {
        margin-top: 20px;
    }

    p a {
        color: #388e3c; /* Green Link */
    }

    p a:hover {
        text-decoration: underline;
    }
</style>

</head>
<body>
	<div class="container">
		<div class="row p-5">
			<div class="col-md-6 offset-md-3">
				<div class="card">
					<div class="card-body">
						<h3 class="text-center text-success">Register</h3>

                        <!-- ✅ Show success message -->
                        <%
                            String successMsg = (String) request.getAttribute("sucMsg");
                            if (successMsg != null) {
                        %>
                            <div class="alert alert-success"><%= successMsg %></div>
                        <%
                            }
                        %>

                        <!-- ✅ Show error message -->
                        <%
                            String failMsg = (String) request.getAttribute("failMsg");
                            if (failMsg != null) {
                        %>
                            <div class="alert alert-danger"><%= failMsg %></div>
                        <%
                            }
                        %>

						<form action="Register" method="post">
							<div class="form-group">
								<label for="usn">USN</label>
								<input type="text" class="form-control" name="usn" required>
								
								<label for="name">Name</label>
								<input type="text" class="form-control" name="name" required>

								<label for="email">Email</label>
								<input type="email" class="form-control" name="email" required>

								<label for="password">Password</label>
								<input type="password" class="form-control" name="password" required>
							</div>

							<div class="text-center mt-3">
								<button type="submit" class="btn btn-primary">Register</button>
								<p class="text-center mt-3">
						Already have an account? <a href="login.jsp">Login</a>
					</p>
							</div>
						</form>

					</div>
				</div>
			</div>
		</div>
	</div>

</body>
</html>

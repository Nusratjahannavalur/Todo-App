<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
           background: linear-gradient(to right, #81c784, #66bb6a); /* Light Green Background */
            font-family: 'Poppins', sans-serif;
        }

        .card {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .card-body {
            padding: 30px;
        }

        h2 {
            color: #388e3c; /* Darker Green for Heading */
            margin-bottom: 20px;
        }

        .form-label {
            font-weight: bold;
            color: #388e3c; /* Dark Green Label */
        }

        .form-control {
            border-radius: 5px;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #81c784; /* Light Green Border */
        }

        .form-control:focus {
            border-color: #66bb6a; /* Darker Green Focus */
            box-shadow: 0 0 5px #66bb6a;
        }

        .btn-primary {
            background-color: #81c784; /* Light Green */
            color: white;
            font-weight: bold;
            border-radius: 50px;
            padding: 12px 20px;
            transition: all 0.3s ease-in-out;
        }

        .btn-primary:hover {
            background-color: #66bb6a; /* Darker Green on hover */
            transform: scale(1.05);
        }

        .alert {
            font-weight: bold;
        }

        .text-center {
            text-align: center;
        }

        .mt-3 {
            margin-top: 20px;
        }

        p a {
            color: #388e3c; /* Green Link */
        }

        p a:hover {
            text-decoration: underline;
        }
        
        .forgot-password {
            color: #388e3c; /* Green Link */
            text-decoration: none;
        }

        .forgot-password:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="card shadow-lg p-4">
                    <h2 class="text-center mb-4">Login</h2>
                    
                    <%-- Display Error Message if Login Fails --%>
                    <% 
                        String errorMsg = (String) session.getAttribute("errorMsg");
                        if (errorMsg != null) {
                    %>
                        <div class="alert alert-danger"><%= errorMsg %></div>
                    <% 
                        session.removeAttribute("errorMsg"); 
                        }
                    %>

                    <form action="LoginServlet" method="post">
                        <div class="mb-3">
                            <label for="email" class="form-label">Email Address</label>
                            <input type="email" class="form-control" name="email" id="email" placeholder="Enter your email" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" name="password" id="password" placeholder="Enter your password" required>
                        </div>
                        
                        <button type="submit" class="btn btn-primary w-100">Login</button>
                    </form>
                   
                    <p class="text-center mt-3">Don't have an account? <a href="register.jsp">Register</a></p>
                    <!-- Forgot Password Link -->
                    <p class="text-center mt-2"><a class="forgot-password" href="forgot_password.jsp">Forgot Password?</a></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

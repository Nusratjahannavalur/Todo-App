<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
<%@include file="components/all_css.jsp"%>

<style>
    body {
         background: linear-gradient(to right, #81c784, #66bb6a);  /* Light Green Gradient Background */
         font-family: 'Poppins', sans-serif;
    }
    .card {
        background: white;
        border-radius: 10px;
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    }
    .card-body {
        padding: 30px;
    }
    h3 {
        color: #388e3c;  /* Dark Green for Heading */
    }
    .form-label {
        color: #388e3c;  /* Dark Green Label */
        font-weight: bold;
    }
    .form-control {
        border-radius: 5px;
        padding: 10px;
        font-size: 16px;
        border: 1px solid #81c784;  /* Light Green Border */
    }
    .form-control:focus {
        border-color: #66bb6a;  /* Darker Green Focus */
        box-shadow: 0 0 5px #66bb6a;
    }
    .btn-primary {
        background-color: #81c784;  /* Light Green Button */
        color: white;
        font-weight: bold;
        border-radius: 50px;
        padding: 12px 20px;
        transition: all 0.3s ease-in-out;
    }
    .btn-primary:hover {
        background-color: #66bb6a;  /* Darker Green on Hover */
        transform: scale(1.05);
    }
</style>

</head>
<body>
    <%@include file="components/navbar.jsp"%>
    <div class="container">
        <div class="row p-5">
            <div class="col-md-6 offset-md-3">
                <div class="card">
                    <div class="card-body">
                        <h3 class="text-center text-primary">Add Todo</h3>

                        <form action="add_todo" method="post">
                            <div class="form-group">
                                <label for="Todo">Id</label> 
                                <input type="NUMBER" class="form-control" placeholder="id" name="id">
                            
                                <label for="Todo">Todo</label> 
                                <input type="text" class="form-control" placeholder="Enter Todo" name="todo">
                                
                                <label for="Todo">Target-Date</label> 
                                <input type="date" class="form-control" placeholder="Enter Date" name="edate">
                            </div>
                            <div class="form-group">
                                <label for="input-state">Status</label> 
                                <select id="inputstate" class="form-control" name="status">
                                    <option value="Pending" selected>Pending</option>
                                    <option value="Complete">Complete</option>
                                </select>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html>

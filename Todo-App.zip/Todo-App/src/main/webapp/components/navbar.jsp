<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #008000;">  <!-- Light Green Background -->
  <a class="navbar-brand" href="#">TODO-APP</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" 
    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav me-auto"></ul>

    <ul class="navbar-nav ms-7">
      <li class="nav-item active" style="margin-right: 20px;"> <!-- Added margin-right -->
        <a class="nav-link btn" style="background-color: #81c784; color: white; font-weight: bold; transition: background-color 0.3s, transform 0.3s;" href="home.jsp">
         View My Todo
        </a>
      </li>
      <li class="nav-item active" style="margin-right: 20px;"> <!-- Added margin-right -->
        <a class="nav-link btn" style="background-color: #81c784; color: white; font-weight: bold; transition: background-color 0.3s, transform 0.3s;" href="add_todo.jsp">
         Add Todo
        </a>
      </li>
      <li class="nav-item active">
        <a class="nav-link btn" style="background-color: #81c784; color: white; font-weight: bold; transition: background-color 0.3s, transform 0.3s;" href="index.jsp">
        Logout
        </a>
      </li>
    </ul>
  </div>
</nav>

<style>
    .nav-link:hover {
        background-color: #66bb6a; /* Darker Green for hover */
        transform: scale(1.05); /* Slight scaling effect */
    }
</style>

<%@ page import="com.DAO.TodoDAO"%>
<%@ page import="com.DB.DBConnect"%>
<%@ page import="com.entity.TodoDetails"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Edit Todo</title>
<%@include file="components/all_css.jsp"%>

<style>
    body {
        background: linear-gradient(to right, #81c784, #66bb6a);/* Light Blue Background */
    }
    .card {
        background: white;
        border-radius: 10px;
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    }
</style>

</head>
<body>
    <%@include file="components/navbar.jsp"%>
    <div class="container">
        <div class="row p-5">
            <div class="col-md-6 offset-md-3">
                <div class="card">
                    <div class="card-body">
                        <h3 class="text-center text-success">Edit Todo</h3>
                        <%
                        int id = Integer.parseInt(request.getParameter("id"));
                        TodoDAO dao = new TodoDAO(DBConnect.getConnection());
                        TodoDetails t = dao.getTodoById(id);
                        %>
                        <form action="Update" method="post">
                            <input type="hidden" name="id" value="<%=t.getId()%>">

                            <div class="form-group">
                                <label for="Todo">Id</label> 
                                <input type="number" class="form-control" placeholder="id" name="id" value="<%=t.getId()%>">

                                <label for="Todo">Todo</label> 
                                <input type="text" class="form-control" placeholder="Enter Todo" name="todo" value="<%=t.getTodo()%>">
                                
                                <label for="Todo">Target Date</label> 
                                <input type="date" class="form-control" name="edate" value="<%=t.getDate()%>">
                            </div>

                            <div class="form-group">
                                <label for="input-state">Status</label> 
                                <select id="inputstate" class="form-control" name="status">
                                    <option value="Pending" <%=t.getStatus().equals("Pending") ? "selected" : ""%>>Pending</option>
                                    <option value="Complete" <%=t.getStatus().equals("Complete") ? "selected" : ""%>>Complete</option>
                                </select>
                            </div>

                            <div class="text-center">
                                <button type="submit" class="btn btn-primary">Update</button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<%@page import="com.DB.DBConnect" %>
<%@page import="java.sql.Connection" %>

<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Welcome to To-Do App</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

    <%@include file="components/all_css.jsp" %>
    
    <style>
body {
    font-family: 'Poppins', sans-serif;
    background-color: #dcedc8; /* Light Green Background */
}

.hero {
    height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    background: linear-gradient(to right, #81c784, #66bb6a); /* Light Green Gradient */
    color: white;
    padding: 20px;
    position: relative;
    overflow: hidden;
}

.hero h1 {
    font-size: 3.5rem;
    font-weight: bold;
    animation: fadeIn 2s ease-in-out;
}

.hero p {
    font-size: 1.2rem;
    margin-bottom: 20px;
    animation: fadeIn 2.5s ease-in-out;
}

/* Enhanced Buttons */
.btn-custom {
    padding: 12px 30px;
    font-size: 1rem;
    border-radius: 50px;
    font-weight: bold;
    transition: all 0.3s ease-in-out;
    border: none;
    color: white;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
}

/* Soft Green Button */
.btn-light-custom {
    background: linear-gradient(to right, #c8e6c9, #81c784);
}

.btn-light-custom:hover {
    background: linear-gradient(to right, #66bb6a, #388e3c);
    transform: scale(1.1);
}

/* Bold Green Button */
.btn-outline-custom {
    background: linear-gradient(to right, #388e3c, #2c6e2f);
}

.btn-outline-custom:hover {
    background: linear-gradient(to right, #2c6e2f, #1b5e20);
    transform: scale(1.1);
}

/* Feature Section */
.features {
    padding: 60px 0;
    background: #a5d6a7; /* Lighter Green */
    text-align: center;
}

.feature-box {
    background: white;
    padding: 20px;
    border-radius: 10px;
    transition: 0.3s ease-in-out;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

.feature-box:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
}

    </style>
</head>
<body>

<!-- Include Navbar -->
<%@include file="components/home_navbar.jsp" %>

<!-- Hero Section -->
<section class="hero">
   <div>
    <h1>Welcome to To-Do App</h1>
    <p>Stay organized and boost your productivity with our simple & effective task manager.</p>

    <div>
        <a href="login.jsp" class="btn btn-custom btn-light-custom">Login</a>
        <a href="register.jsp" class="btn btn-custom btn-outline-custom">Sign Up</a>
    </div>
</div>

</section>


<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>

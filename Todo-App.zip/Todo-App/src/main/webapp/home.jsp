<%@ page import="java.util.List" %>
<%@ page import="com.DAO.TodoDAO" %>
<%@ page import="com.DB.DBConnect" %>  
<%@ page import="com.entity.TodoDetails" %>

<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>TODO APP</title>
<%@include file="components/all_css.jsp" %>

<style>
    body {
        background-color: #c8e6c9; /* Light Green Background */
        font-family: 'Poppins', sans-serif;
    }

    .table-container {
        background: white;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    }

    h1 {
        margin-top: 20px;
        color: #388e3c; /* Darker Green for Heading */
    }

    .alert {
        font-weight: bold;
    }

    /* Button Style */
    .btn-custom {
        background-color: #81c784; /* Light Green */
        color: white;
        font-weight: bold;
        border-radius: 50px;
        padding: 8px 16px;
        transition: all 0.3s ease-in-out;
    }

    .btn-custom:hover {
        background-color: #66bb6a; /* Slightly darker green on hover */
        transform: scale(1.05);
    }

    .btn-danger {
        background-color: #e57373; /* Light Red for Delete */
        color: white;
    }

    .btn-danger:hover {
        background-color: #ef5350; /* Darker Red on hover */
    }

    .btn-success {
        background-color: #81c784; /* Light Green */
        color: white;
    }

    .btn-success:hover {
        background-color: #66bb6a; /* Darker Green on hover */
    }
</style>

</head>
<body>
<%@include file="components/navbar.jsp" %>
<h1 class="text-center">TODO APP</h1>

<%
String sucMsg = (String) session.getAttribute("sucMsg");
if (sucMsg != null) {
%>
<div class="alert alert-success text-center" role="alert"><%=sucMsg %></div>
<%
session.removeAttribute("sucMsg");
}
%>

<%
String failMsg = (String) session.getAttribute("failMsg");
if (failMsg != null) {
%>
<div class="alert alert-danger text-center" role="alert"><%=failMsg %></div>
<%
session.removeAttribute("failMsg");
}
%>

<div class="container">
    <div class="table-container">
        <table class="table table-striped">
          <thead class="bg-info text-white">
            <tr>
              <th scope="col">No</th>
              <th scope="col">Todo</th>
              <th scope="col">Target Date</th>
              <th scope="col">Status</th>
              <th scope="col">Actions</th>
            </tr>
          </thead>
          <tbody>
          <%
          TodoDAO dao = new TodoDAO(DBConnect.getConnection());
          List<TodoDetails> todoList = dao.getTodo();
          
          for (TodoDetails t : todoList) {  
          %>
            <tr>
              <th><%=t.getId() %></th>
              <td><%=t.getTodo() %></td>  
              <td><%=t.getDate() %></td>
              <td><%=t.getStatus() %></td>
              <td>
                <a href="edit.jsp?id=<%=t.getId()%>" class="btn btn-sm btn-success btn-custom">Edit</a>
                <a href="delete?id=<%=t.getId()%>" class="btn btn-sm btn-danger">Delete</a>
              </td>
            </tr>
          <%
          }
          %>
          </tbody>
        </table>
    </div>
</div>

</body>
</html>
